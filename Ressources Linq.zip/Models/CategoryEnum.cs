namespace ELinq.Models
{
    public enum CategoryEnum
    {
       Food, Clothing, VideoGames, Electronics, Movies   
    }
}