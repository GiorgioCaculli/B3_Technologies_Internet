namespace ELinq.Models
{
    public class Product
    {
        public string Name { get; set; }
        public float Price { get; set; }
        public CategoryEnum Category { get; set; }

        public override string ToString()
        {
            return $"Name: {Name}\tPrice: {Price}\tCategory: {Category.ToString()}";
        }
    }
}