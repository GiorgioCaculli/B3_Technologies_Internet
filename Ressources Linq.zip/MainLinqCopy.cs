﻿using System;
using System.Collections.Generic;
using System.Linq;
using ELinq.Models;

namespace ELinq
{
    public class MainLinqCopy
    {
        private static readonly int[] Numbers = {1, 5, 5, 3, 6, 7, 2, 4, 9, 4, 1, 4, 5};

        private static readonly Product[] Products =
        {
            new Product {Name = "Tomato", Price = 1.25f, Category = CategoryEnum.Food},
            new Product {Name = "Water", Price = 2.50f, Category = CategoryEnum.Food},
            new Product {Name = "Shirt", Price = 10, Category = CategoryEnum.Clothing},
            new Product {Name = "Coat", Price = 25.99f, Category = CategoryEnum.Clothing},
            new Product {Name = "TV", Price = 1000, Category = CategoryEnum.Electronics},
            new Product {Name = "Monster Sword", Price = 49, Category = CategoryEnum.VideoGames},
            new Product {Name = "Inception", Price = 19.99f, Category = CategoryEnum.Movies},
            new Product {Name = "Tablet", Price = 400, Category = CategoryEnum.Electronics},
            new Product {Name = "Sockets", Price = 5, Category = CategoryEnum.Clothing},
            new Product {Name = "The Full Monopoly", Price = 15, Category = CategoryEnum.VideoGames},
            new Product {Name = "Chips", Price = 4.99f, Category = CategoryEnum.Food},
            new Product {Name = "Smartphone", Price = 250.99f, Category = CategoryEnum.Electronics},
            new Product {Name = "Pajama", Price = 10.99f, Category = CategoryEnum.Clothing}
        };

        /*  public static void Main(string[] args)
          {
              Exercise1();
              Exercise2();
              Exercise3();
              Exercise4();
              Exercise5();
              Exercise6();
              Exercise7();
              Exercise8();
              Exercise9();
              Exercise10();
              Exercise11();
          }*/
    }
}

