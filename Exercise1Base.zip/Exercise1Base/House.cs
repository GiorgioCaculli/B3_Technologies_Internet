namespace initializers.Exercise1.Exercise1Base
{
    public class House
    {
       public string Street { get; set; }
       public int Number { get; set; }
    }
}