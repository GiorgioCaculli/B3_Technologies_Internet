using System.Collections.Generic;

namespace initializers.Exercise1.Exercise1Base
{
    public class Town
    {
        public string Name { get; set; }
        public IList<House> Houses { get; set; }

        public Town(string name)
        {
            Name = name;
        }
    }
}