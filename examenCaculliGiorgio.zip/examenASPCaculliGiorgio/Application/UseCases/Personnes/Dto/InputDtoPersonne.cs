namespace Application.UseCases.Personnes.Dto
{
    public class InputDtoPersonne
    {
        public string Nom { get; set; }
        public string Prenom { get; set; }
    }
}
