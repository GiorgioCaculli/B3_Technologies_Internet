namespace Application.UseCases.Parcours.Dto
{
    public class InputDtoParcours
    {
        public string Nom { get; set; }
        public int TempsMarcheMinutes { get; set; }
        public int TempsCourseMinutes { get; set; }
    }
}
