export class Personne {
  identifiant?: number = 0;
  nom: string = "";
  prenom: string = "";
}
