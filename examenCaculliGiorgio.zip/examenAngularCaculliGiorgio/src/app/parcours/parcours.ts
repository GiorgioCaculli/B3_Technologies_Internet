export class Parcours {
  identifiant?: number = 0;
  nom: string = "";
  tempsMarcheMinutes: number = 0;
  tempsCourseMinutes: number = 0;
}
