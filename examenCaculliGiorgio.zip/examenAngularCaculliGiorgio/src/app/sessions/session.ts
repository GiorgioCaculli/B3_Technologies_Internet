export class Session {
  id?: number = 0;
  idUtilisateur: number = 0;
  idParcours: number = 0;
  typeSession: string = "";
  tempsMinutes: number = 0;
}
